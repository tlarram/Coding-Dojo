package com.timlarramore.examtwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamtwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
