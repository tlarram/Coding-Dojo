package com.timlarramore.examtwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamtwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamtwoApplication.class, args);
	}

}
