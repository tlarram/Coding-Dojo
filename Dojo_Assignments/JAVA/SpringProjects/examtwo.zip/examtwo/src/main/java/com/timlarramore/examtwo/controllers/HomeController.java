package com.timlarramore.examtwo.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.timlarramore.examtwo.models.Course;
import com.timlarramore.examtwo.models.Student;
import com.timlarramore.examtwo.models.User;
import com.timlarramore.examtwo.services.MainService;
import com.timlarramore.examtwo.services.UserService;



@Controller
public class HomeController {
	
	@Autowired
	MainService mainServ;
	@Autowired
	UserService userServ;
	
	
	@GetMapping("/classes")
    public String dashboard(HttpSession session,Model model) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/logout";
		}
		
		Long userId = (Long) session.getAttribute("userId");
		model.addAttribute("user", userServ.findById(userId));
		List<Course> courses= mainServ.allCourses();
		model.addAttribute("courses", courses);
    	return "dashboard.jsp";
    }
	
	@GetMapping("/classes/new")
	public String viewForm (HttpSession session, Model model) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/logout";
		}
		
		
		model.addAttribute("course", new Course());
		return "courseForm.jsp";
	}
	@PostMapping("/classes/new")
	public String processForm (@Valid @ModelAttribute("course")Course course, BindingResult result, Model model, HttpSession session) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/logout";
		}
		if(result.hasErrors()) {
			List<Course> classes= mainServ.allCourses();
			model.addAttribute("classes", classes);
			return "courseForm.jsp";
		} else {
			mainServ.createCourse(course);
			return "redirect:/classes";
		}
		
	}
	@GetMapping("/classes/{courseId}")
	public String getCourseById(@ModelAttribute("student")Student student,@PathVariable("courseId")Long id,Model model, HttpSession session) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/logout";
		}
		Long userId = (Long) session.getAttribute("userId");
		model.addAttribute("user", userServ.findById(userId));
		Course course = mainServ.findCourse(id);
		model.addAttribute("course", course);
		List<Student> students= mainServ.allStudents();
		model.addAttribute("students", students);
		return "oneCourse.jsp";
	}
	@PostMapping("/classes/new/{courseId}")
	public String processStudentForm (@Valid @ModelAttribute("student")Student student, BindingResult result, Model model,@PathVariable("courseId")Long id, HttpSession session) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/logout";
		}
		if(result.hasErrors()) {
			List<Student> students= mainServ.allStudents();
			model.addAttribute("student", students);
			return "courseForm.jsp";
		} else {
			mainServ.createStudent(student);
			return "redirect:/classes/{courseId}";
		}
		
	}
	
	@PutMapping("/classes/join/{courseId}")
	public String StudentForm (@Valid @ModelAttribute("student")Student student, BindingResult result, Model model,@PathVariable("courseId")Long id, HttpSession session) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/logout";
		}
		if(result.hasErrors()) {
			List<Student> students= mainServ.allStudents();
			model.addAttribute("students", students);
			return "courseForm.jsp";
		} else {
			Course course = (Course) mainServ.allCourses();
			mainServ.updateCourse(course);
			return "redirect:/classes/{courseId}";
		}
		
	}
	
	@GetMapping("/classes/edit/{id}")
	public String showEditForm(@PathVariable("id")Long id, Model model, HttpSession session) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/logout";
		}
		Course course= mainServ.findCourse(id);
		model.addAttribute("course", course);
		if(course.getUser().getId().equals((Long) session.getAttribute("userId"))) {
			return "editForm.jsp";
		} else
		return "redirect:/classes";
	}
	
		
	@PutMapping("/classes/edit/{id}")
	public String processEditForm(@Valid @ModelAttribute("course") Course course,BindingResult result, HttpSession session) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/logout";
		}
		if (result.hasErrors()) {
			return "editForm.jsp";
		} else {
		mainServ.updateCourse(course);
		return "redirect:/classes";	
	}
	}
	@DeleteMapping("classes/delete/{id}")
	public String processDelete(@PathVariable("id") Long id, HttpSession session) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/logout";
		}
		mainServ.deleteCourse(id);
		return "redirect:/classes";
	}

}
