package com.timlarramore.examtwo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timlarramore.examtwo.models.Course;
import com.timlarramore.examtwo.models.Student;
import com.timlarramore.examtwo.models.User;
import com.timlarramore.examtwo.repositories.CourseRepository;
import com.timlarramore.examtwo.repositories.StudentRepository;
import com.timlarramore.examtwo.repositories.UserRepository;


@Service
public class MainService {
	

		
		@Autowired
		private CourseRepository courseRepo;
		@Autowired
		private UserRepository userRepo;
		@Autowired
		private StudentRepository studentRepo;
		
		public List<Course> allCourses(){
			return courseRepo.findAll();
		}
		
		public List<Student> allStudents(){
			return studentRepo.findAll();
		}
		
		public Course findCourse(Long id) {
			Optional<Course> optionalCourse= courseRepo.findById(id);
			if(optionalCourse.isPresent()) {
				return optionalCourse.get();
			} else {
				return null;
			}
		}
		
		public Course createCourse(Course course) {
			return courseRepo.save(course);
			
		}
		public Student createStudent(Student student) {
			return studentRepo.save(student);
		}
		
		public Course updateCourse(Course course) {
			return courseRepo.save(course);
		}
		
		//delete
		public void deleteCourse (long id) {
			Optional<Course> optionalCourse= courseRepo.findById(id);
			if(optionalCourse.isPresent()) {
				courseRepo.deleteById(id);
				}
		}
		
//		public void recieveVote(Long courseId, Long userId) {
//			Course course = this.findCourse(courseId);
//			User user = userServ.findById(userId);
//			course.getUsers().add(user);
//			courseRepo.save(course);
//		}
//	}

}
