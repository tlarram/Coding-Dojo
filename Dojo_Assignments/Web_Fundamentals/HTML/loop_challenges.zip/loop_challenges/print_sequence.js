var i=5.5;
while(i>-3.5){i=i-1.5; console.log(i)}