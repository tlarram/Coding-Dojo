console.log("page loaded...");

var toddElement=document.getElementById("todd")
function hide() {
    toddElement.remove();
    console.log(hide)
}


var philElement=document.getElementById("phil")
function hide1() {
    philElement.remove();
    console.log(hide1)
}


var Jane = document.getElementById("Jane");
function changeJane() {
    Jane.innerText= "Tim"
}


